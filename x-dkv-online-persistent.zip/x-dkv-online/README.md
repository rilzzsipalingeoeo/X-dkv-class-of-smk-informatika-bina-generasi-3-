# X DKV Class Hub — Online Persistent

Versi ini memakai Supabase supaya nama, role, dan pas foto anggota tersimpan online.

## Cara mengaktifkan
1. Buat project di Supabase.
2. Buka SQL Editor, jalankan semua isi `schema.sql`.
3. Di Authentication > Users, buat 1 akun admin (email + password).
4. Buka Project Settings > API, salin Project URL dan anon public key.
5. Buka `index.html` dan ganti:
   - GANTI_DENGAN_SUPABASE_URL
   - GANTI_DENGAN_SUPABASE_ANON_KEY
6. Upload folder ini ke Netlify, Vercel, GitHub Pages, atau hosting statis lain.

## Cara kerja
- Pengunjung bisa melihat 41 anggota dan jadwal.
- Admin login untuk mengubah nama, role, dan foto.
- Foto disimpan di Supabase Storage.
- Nama/role/url foto disimpan di database.
- Karena tersimpan di server, data tetap ada saat dibuka dari HP/PC lain.

## Keamanan
Jangan memasukkan `service_role` key ke HTML. Yang boleh dimasukkan ke browser hanya `anon public key`.
Akun admin yang punya password adalah pihak yang dapat mengubah data.
