X DKV — CLASS HUB

Isi folder:
- index.html : web kelas lengkap, tanpa library eksternal.

Fitur:
- 41 anggota X DKV.
- Role awal contoh (Ketua, Wakil, Sekretaris, Bendahara, Koordinator, Anggota).
- Setiap anggota punya slot pas foto yang bisa diisi dari HP/laptop.
- Nama dan role bisa diedit langsung.
- Data anggota dan foto disimpan di browser (localStorage).
- Jadwal X DKV diambil dari kolom X DKV pada foto jadwal yang diberikan.
- Galeri kelas punya 4 slot foto yang bisa diganti.
- Responsif untuk HP.

Cara pakai:
1. Buka index.html di browser.
2. Pada kartu anggota, ubah nama, role, dan pilih pas foto.
3. Pada Galeri, tekan salah satu slot untuk mengganti foto.
